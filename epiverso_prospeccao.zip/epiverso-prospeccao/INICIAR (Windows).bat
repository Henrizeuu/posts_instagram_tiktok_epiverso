@echo off
chcp 65001 >nul
title Epiverso Prospeccao - deixe esta janela aberta
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   O Node.js nao esta instalado neste computador.
  echo   Vou abrir o site: baixe a versao LTS, instale ^(Avancar, Avancar, Concluir^)
  echo   e depois abra este arquivo de novo.
  echo.
  start "" "https://nodejs.org/pt-br/download"
  pause
  exit /b
)
node "app\servidor.mjs"
echo.
echo   O sistema foi fechado. Os envios param ate voce abrir de novo.
pause
